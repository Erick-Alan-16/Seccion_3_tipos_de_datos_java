
package variables03;

public class Variables03 {

    public static void main(String[] args) {
        
        //se arreglaron las declaraciones de int, double y string y se agrego una mas de double
        boolean bool = true;
        
        int intVar1 = 1;
        int intVar2 = 2;
        int intVar3 = 3;
    
        double doubleVar1 = 1.1;
        double doubleVar2 = 2.1;
        double doubleVar3 = 3.1;
        double doubleVar4 = 4.1;
        
        String stringVar1 = "1";
        String stringVar2 = "2";

        //Don't edit these print statements
        System.out.println("bool = "        +bool);
        System.out.println("intVar1 = "     +intVar1);
        System.out.println("intVar2 = "     +intVar2);
        System.out.println("intVar3 = "     +intVar3);
        System.out.println("doubleVar1 = "  +doubleVar1);
        System.out.println("doubleVar2 = "  +doubleVar2);
        System.out.println("doubleVar3 = "  +doubleVar3);
        System.out.println("doubleVar4 = "  +doubleVar4);
        System.out.println("stringVar1 = "  +(stringVar1 +1));
        System.out.println("stringVar2 = "  +(stringVar2 +2));
    }
}
