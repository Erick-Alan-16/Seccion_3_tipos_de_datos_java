
package chickens01;

public class Chickens01 {
    public static void main(String[] args) {
        //Put yout code here
        
        int eggsPerChicken=5;
        int chickenCount=8;
        
        int totalEggsLunes;
        totalEggsLunes = eggsPerChicken*chickenCount;
        chickenCount ++;
        
        int totalEggsMartes;
        totalEggsMartes = chickenCount*eggsPerChicken+totalEggsLunes;
        chickenCount = chickenCount/2;
        
        int totalEggsMiercoles;
        totalEggsMiercoles = chickenCount-eggsPerChicken+totalEggsMartes;
               
        int totalEggs;
        totalEggs = totalEggsMiercoles;
        System.out.println(totalEggs);
    }   
}


