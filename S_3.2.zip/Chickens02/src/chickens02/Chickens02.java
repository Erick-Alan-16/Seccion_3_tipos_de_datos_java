
package chickens02;

public class Chickens02 {
    public static void main(String[] args) {
        //Put yout code here
        
        //variable constante - palabra reservada final (se usa con mayusculas)
        final double EGGS_BENEFICIO = 0.18;
        double eggsLunes = 100;
        double eggsMartes = 121;
        double eggsMiercoles = 117;
        
        double daily_Average = (eggsLunes+eggsMartes+eggsMiercoles)/3;
        double monthly_Average = daily_Average*30;
        double monthly_Profit = monthly_Average*EGGS_BENEFICIO;

        System.out.println("Daily Average:   " +daily_Average);
        System.out.println("Monthly Average: " +monthly_Average);
        System.out.println("Monthly Profit:  $" +monthly_Profit);
    }
    
}
