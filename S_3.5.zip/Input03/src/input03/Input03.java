package input03;
import java.util.Scanner;
class Input03 {

    public static void main(String[] args) {
        //Create a Scanner
        Scanner scan = new Scanner(System.in);
        //Find and print the sum of three integers entered by the user
        int suma;
        
        System.out.println("Numero 1: ");
        int x1 = scan.nextInt();
        System.out.println("Numero 2: ");
        int x2 = scan.nextInt();
        System.out.println("Numero 3: ");
        int x3 = scan.nextInt();
        
        suma = x1+x2+x3;
        System.out.println("El total de la suma es: " +  suma + " xd");
        
        //Remember to close the Scanner
        scan.close();
    }
}
