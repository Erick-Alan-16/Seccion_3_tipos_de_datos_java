package parsing01;

public class Parsing01 {
    public static void main(String[] args) {
        //Declare and intitialize 3 Strings: shirtPrice, taxRate, and gibberish
        
        String shirtPrice, taxRite, gibberish;
        shirtPrice = "15";
        taxRite = "0.05";
        gibberish = "887ds7nds87dsfs";
        

        //Parse shirtPrice and taxRate, and print the total tax
        double doubleshirtPrice = Double.parseDouble(shirtPrice);
         double doubletaxRite = Double.parseDouble(taxRite);
        System.out.println("El total de tax es:  " + doubleshirtPrice*doubletaxRite);
        
        
        
    }
    
}
