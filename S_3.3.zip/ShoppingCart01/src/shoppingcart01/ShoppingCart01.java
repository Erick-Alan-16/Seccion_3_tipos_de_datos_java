
package shoppingcart01;

public class ShoppingCart01 {
    public static void main(String[] args) {
        // Declare and initialize String variables.  Do not initialize message yet.
         //declarar e inicializar las variables de cadena
        String custName;
        String itemDesc;
        String message;

        // Assign the message variable 
        //asigna a message valor concatenado donde incluya a custName e itemDesc y una literal de cadena.
        custName = "Alan";
        itemDesc = "Shirts";
        message = custName+" wants to purchase a "+itemDesc;
        
        // Print and run the code
        System.out.println(message);
        
    }
}
