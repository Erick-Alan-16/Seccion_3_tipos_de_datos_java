
package shoppingcart02;

public class ShoppingCart02 {
    public static void main(String[] args) {

        String custName= "Alan";
        String itemDesc = "Shirts";
            
        // Declare and initialize numeric fields: price (precio), tax(impuesto sobre ventas), quantity(numero de productos). 
        double price;
        double tax;
        int quantity;
        
        // Declare and assign a calculated totalPrice
        double totalPrice;
        price = 12.5;
        tax = 0.78;
        quantity = 2;
        
        // Modify message to include quantity 
        String message = custName + " wants to purchase " + quantity + " " + itemDesc;
        System.out.println(message);
        
        // Print another message with the total cost
        String message_total;
        message_total = "Total cost with taxt is: " + (quantity*price + tax);
        System.out.println(message_total);
    }    
}
